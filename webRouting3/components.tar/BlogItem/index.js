import {Component} from 'react'
import {Link} from 'react-router-dom'

import './index.css'

class BlogItem extends Component {
  render() {
    const {blogsData} = this.props
    const {id, title, imageUrl, avatarUrl, author, topic} = blogsData

    return (
      <Link to={`/blogs/${id}`} className="item-link">
        <div className="blogs-list-item">
          <div className="blog-image-card">
            <img src={imageUrl} className="blog-image" alt={`item${id}`} />
          </div>
          <div className="blog-details-card">
            <h1 className="topic">{topic}</h1>
            <h1 className="title">{title}</h1>
            <div className="blog-profile">
              <img
                src={avatarUrl}
                className="blog-profile-img"
                alt={`avatar${id}`}
              />
              <p className="blog-profile-name">{author}</p>
            </div>
          </div>
        </div>
      </Link>
    )
  }
}

export default BlogItem
