import './index.css'
import BlogList from '../BlogList'

const Home = () => (
  <div className="home-container">
    <div className="user-info">
      <img
        src="https://assets.ccbp.in/frontend/react-js/profile-img.png"
        className="user-profile"
        alt="profile"
      />
      <h1 className="user-name">Wade Warren</h1>
      <p className="user-job">Software developer at UK</p>
    </div>
    <BlogList />
  </div>
)

export default Home
