const MatchCard = props => {
  const {recentMatchData} = props
  console.log(recentMatchData)

  return <div className="match-card">This is match card</div>
}

export default MatchCard
