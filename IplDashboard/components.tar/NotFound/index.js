const NotFound = () => <div className="not-found">Not Found</div>

export default NotFound
