import './index.css'

const BlogItem = props => {
  const {blogObject} = props
  const {title, description, publishedDate} = blogObject
  return (
    <li className="blog-list-item">
      <div className="blog-details-container">
        <h1 className="blog-title">{title}</h1>
        <p className="publisher-date">{publishedDate}</p>
      </div>
      <p className="blog-description">{description}</p>
    </li>
  )
}

export default BlogItem
