import './index.css'

import BlogItem from '../BlogItem'

const BlogList = props => {
  const {blogsList} = props

  return (
    <div className="blog-container">
      <ul className="blogs-list">
        {blogsList.map(eachBlog => (
          <BlogItem key={eachBlog.id} blogObject={eachBlog} />
        ))}
      </ul>
    </div>
  )
}

export default BlogList
